Pattern Observer | Atividade de Arquitetura de Software
